---
name: testing
description: Add or run verification for work that already exists. Selects the Build bucket and the testing loop.
---

# /testing

Copyright (c) 2026 Devrecated.

Bucket: **Build**. Loop: **testing**.

Steps come from `loops.testing` in [skill-catalog.yaml](../skills/autodevelop/skill-catalog.yaml). An interrupted session resumes at `webapp-testing`. The loop ends at `verify-ticket`.

Must never:

- Deploy
- Send mail
- Invent a ticket number
