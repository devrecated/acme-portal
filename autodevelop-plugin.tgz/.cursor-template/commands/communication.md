---
name: communication
description: Stakeholder mail, weekly recap, and digests. Selects the Message bucket and the weekly reporting loop.
---

# /communication

Copyright (c) 2026 Devrecated.

Bucket: **Message**. Loop: **weekly_reporting**. This bucket always confirms before it acts.

Steps come from `loops.weekly_reporting` in [skill-catalog.yaml](../skills/autodevelop/skill-catalog.yaml).

Show **to, subject, HTML as text, ticket link, and Firestore project**, then wait for an explicit yes. Full rule: [stakeholder-mail](../rules/autodevelop/process/stakeholder-mail.mdc).

Must never:

- Write Firestore `mail` without `--confirm <token>`
- Invent a confirm token
- Mail a recipient who is not on the instance allowlist unless the human retypes the address
- Log the message body, tokens, or raw PII
