---
name: release
description: Commit, preview, staging, promote, production. Selects the Ship bucket and the ship loop.
---

# /release

Copyright (c) 2026 Devrecated.

Bucket: **Ship**. Loop: **ship**. This bucket always confirms before it acts.

Load branch names and ask flags before touching a shared branch:

```bash
node .cursor/skills/autodevelop/scripts/branches-load.mjs
```

Steps come from `loops.ship` in [skill-catalog.yaml](../skills/autodevelop/skill-catalog.yaml). On a single-branch instance, promote and hotfix-to-release refuse.

Four phrases, four separate authorizations. Git is not deploy.

| Action | Phrase |
|---|---|
| Push the staging branch | `YES PUSH TO MASTER` |
| Deploy staging locally | `DEPLOYED TO STAGING` |
| Promote or hotfix the production branch | `YES PUSH TO RELEASE` |
| Deploy production locally | `DEPLOYED TO PRODUCTION` |

Must never:

- Push a shared branch or deploy without the exact phrase in this chat. Approving a risk list, "yes", or a ticked checkbox is not enough
- Force-push
- Treat `/commit-push-release` as anything but a hotfix path
