---
name: new-feature
description: Notes to ticket to implementation to verification. Selects the Board bucket and the ticket lifecycle loop.
---

# /new-feature

Copyright (c) 2026 Devrecated.

Bucket: **Board**. Loop: **ticket_lifecycle**.

Steps come from `loops.ticket_lifecycle` in [skill-catalog.yaml](../skills/autodevelop/skill-catalog.yaml). An interrupted session resumes at `pull-project-work`, not at `create-ticket` — restarting earlier files a duplicate.

Must never:

- Create an issue before the human types **create** or names `#N`
- Open a second issue for the same request, or create child issues
- Send mail without the confirm token and the instance allowlist
- Deploy
