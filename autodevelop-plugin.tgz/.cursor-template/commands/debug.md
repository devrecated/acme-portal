---
name: debug
description: Reproduce, isolate, and prove a fix for a defect. Selects the Build bucket and the debug loop.
---

# /debug

Copyright (c) 2026 Devrecated.

Bucket: **Build**. Loop: **debug**.

Steps come from `loops.debug` in [skill-catalog.yaml](../skills/autodevelop/skill-catalog.yaml). An interrupted session resumes at `diagnosing-bugs`.

Must never:

- Deploy. This loop ends at a proven fix — shipping it is `/release` and a separate phrase
- Send mail
- Invent a ticket number
