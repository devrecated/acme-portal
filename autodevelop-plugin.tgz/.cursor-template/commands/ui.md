---
name: ui
description: Frontend work — layout, components, React, styling, mobile chrome. Selects the UI bucket.
---

# /ui

Copyright (c) 2026 Devrecated.

Bucket: **UI**. No loop.

Select playbooks from `mcp_buckets.ui` in [skill-catalog.yaml](../skills/autodevelop/skill-catalog.yaml). Do not name a skill yourself — the bucket picks it, capped at six.

Must never:

- Expose third-party skill names as the tool surface
- Send mail
- Deploy

Product work still needs a bound ticket. If none exists, stop and follow [ticket-required](../rules/autodevelop/process/ticket-required.mdc).
