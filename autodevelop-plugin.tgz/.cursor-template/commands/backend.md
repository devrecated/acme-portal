---
name: backend
description: API, services, and non-UI product work. Selects the Build bucket.
---

# /backend

Copyright (c) 2026 Devrecated.

Bucket: **Build**. No loop — use `/debug` or `/testing` when the work is one of those.

Select playbooks from `mcp_buckets.build` in [skill-catalog.yaml](../skills/autodevelop/skill-catalog.yaml).

Must never:

- Send mail
- Deploy
- Invent a ticket number

Product work still needs a bound ticket. If none exists, stop and follow [ticket-required](../rules/autodevelop/process/ticket-required.mdc).
