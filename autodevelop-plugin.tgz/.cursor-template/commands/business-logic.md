---
name: business-logic
description: Domain rules, schema, and validation. Selects the Build bucket.
---

# /business-logic

Copyright (c) 2026 Devrecated.

Bucket: **Build**. No loop.

Select playbooks from `mcp_buckets.build` in [skill-catalog.yaml](../skills/autodevelop/skill-catalog.yaml). Domain modeling and database design are in that set.

Must never:

- Send mail
- Deploy
- Invent a ticket number

Product work still needs a bound ticket. If none exists, stop and follow [ticket-required](../rules/autodevelop/process/ticket-required.mdc).
