# Shipped Cursor kit

Copyright (c) 2026 Devrecated.

This folder is the Autodevelop **product** plugin payload. `.cursor-plugin/plugin.json` points here. `pnpm autodevelop:import` installs this tree as the user-scope plugin.

| Path | Workspace (this repo) | Product (customers) |
|---|---|---|
| Rules, hooks, commands, agents, kit skills | `.cursor/` | `.cursor-template/` |

This Autodevelop checkout still uses `.cursor/` so we can develop the host without treating ourselves as a customer. A consumer repo (for example acme-portal) uses the plugin from this folder plus its own instance bindings under `.cursor/skills/<slug>/`.

Hook commands in `hooks.json` are rooted at `.cursor-template/hooks/`. Do not put `services/`, tokens, or instance `config.json` here.
