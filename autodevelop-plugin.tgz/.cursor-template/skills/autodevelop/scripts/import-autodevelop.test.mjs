/**
 * Copyright (c) 2026 Devrecated
 */
import test from "node:test";
import assert from "node:assert/strict";
import { mkdirSync, mkdtempSync, writeFileSync, existsSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  COLLIDING_SKILLS,
  applyImport,
  listCollidingSkillDirs,
  planImport,
  remainingSkillsByCategory,
  renderCategoriesMarkdown,
} from "./import-autodevelop.mjs";
import { findKitRoot } from "./config-load.mjs";

test("collision list is unique and complete", () => {
  assert.equal(new Set(COLLIDING_SKILLS).size, COLLIDING_SKILLS.length);
  assert.ok(COLLIDING_SKILLS.length >= 90, `expected 90+ colliding names, got ${COLLIDING_SKILLS.length}`);
  assert.ok(COLLIDING_SKILLS.includes("onboard-client"));
  assert.ok(COLLIDING_SKILLS.includes("identify-skills"));
});

test("listCollidingSkillDirs only matches allowlisted SKILL.md folders", () => {
  const root = mkdtempSync(join(tmpdir(), "ad-import-"));
  mkdirSync(join(root, "tickets", "ask-adam"), { recursive: true });
  mkdirSync(join(root, "tickets", "keep-me"), { recursive: true });
  mkdirSync(join(root, "gsap", "unique-wave"), { recursive: true });
  writeFileSync(join(root, "tickets", "ask-adam", "SKILL.md"), "# ask-adam\n");
  writeFileSync(join(root, "tickets", "keep-me", "SKILL.md"), "# keep\n");
  writeFileSync(join(root, "gsap", "unique-wave", "SKILL.md"), "# gsap\n");
  const found = listCollidingSkillDirs(root);
  assert.deepEqual(
    found.map((item) => `${item.category}/${item.name}`),
    ["tickets/ask-adam"],
  );
});

test("applyImport removes collisions, keeps unique skills, writes CATEGORIES.md", () => {
  const home = mkdtempSync(join(tmpdir(), "ad-home-"));
  const skills = join(home, ".cursor", "skills");
  mkdirSync(join(skills, "tickets", "ask-adam"), { recursive: true });
  mkdirSync(join(skills, "gsap", "unique-wave"), { recursive: true });
  writeFileSync(join(skills, "tickets", "ask-adam", "SKILL.md"), "# ask-adam\n");
  writeFileSync(join(skills, "gsap", "unique-wave", "SKILL.md"), "# gsap\n");
  const kitRoot = findKitRoot();
  const plan = planImport({ kitRoot, home });
  assert.match(plan.commandSource, /\.cursor-template\/commands\/import-autodevelop\.md$/);
  applyImport(plan);
  assert.equal(existsSync(join(skills, "tickets", "ask-adam")), false);
  assert.equal(existsSync(join(skills, "gsap", "unique-wave", "SKILL.md")), true);
  const md = readFileSync(join(skills, "CATEGORIES.md"), "utf8");
  assert.match(md, /unique-wave/);
  assert.doesNotMatch(md, /ask-adam/);
  assert.deepEqual(remainingSkillsByCategory(skills).gsap, ["unique-wave"]);
  assert.match(renderCategoriesMarkdown({ gsap: ["unique-wave"] }), /## gsap \(1\)/);
});
