# Kit skills

Cursor walks these trees recursively; slash names stay the skill folder (`/ask-adam`, `/create-ticket`).

Do **not** reuse a skill folder name in more than one tree — identity is the folder that contains `SKILL.md`.

```text
.cursor/skills/
├── autodevelop/           # thin local wrappers + loaders/registry/examples
└── <client-name>/         # consumer bindings (board, people, docs URLs)
```

Third-party playbooks are **hosted** under [services/host/skills/third-party/](../../services/host/skills/third-party) and reached through the bucket tools — they are no longer vendored into `.cursor/skills/`. The autodevelop playbook bodies are hosted too; `.cursor/skills/autodevelop/` keeps only the thin wrapper stubs plus the loaders, registry, scripts, and kit examples. The instance bind (`config.json`, `.policies/`, `.configuration/`) lives at the repo-root [`.autodevelop/`](../../.autodevelop), not under this tree.

**Test:** product or workflow → `autodevelop/`; board ids, people, hosts, allowlists → `<client-name>/`; vendored OSS → hosted `services/host/skills/third-party/`. Local discovery is [identify-skills](../../services/host/skills/autodevelop/discovery/identify-skills/SKILL.md): only client skills stay on disk, while autodevelop and third-party playbooks come from the bucket tools. New client trees: [onboard-client](../../services/host/skills/autodevelop/bootstrap/onboard-client/SKILL.md). One-instance pack is the operator CLI `pnpm pack:client` ([scripts/pack-client/README.md](../../scripts/pack-client/README.md)), not a skill.

See [docs/configure.md](../../docs/configure.md).
