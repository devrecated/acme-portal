# Autodevelop kit

Copyright (c) 2026 Devrecated.

This archive is the kit the customer GitHub Package applies into a consumer repository.
It is not the hosted brain, API, or worker.

Clients install the private `@devrecated/autodevelop` tarball. `npx autodevelop login`
extracts this tar and writes rules, hooks, commands, agents, and kit skills into `.cursor/`.
The Autodevelop kit copies missing starter files into `.autodevelop/`.
A live `config.json` is never overwritten.

Do not put tokens or `services/` in this archive.
