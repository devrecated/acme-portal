# Autodevelop Cursor plugin

Copyright (c) 2026 Devrecated.

This archive is the shippable Cursor plugin. It is not the hosted brain, API, or worker.

Extract, then point the user-scope plugin at this folder:

```bash
ln -sfn /path/to/autodevelop-plugin ~/.cursor/plugins/local/autodevelop
```

`pnpm admin init-company --local-repo <consumer>` writes this tar into the consumer and applies the kit into that repo’s `.cursor/` tree (rules, hooks, commands, agents, kit skills). Instance bindings stay under `.cursor/skills/<slug>/`.

Do not put tokens or `services/` in this archive.
