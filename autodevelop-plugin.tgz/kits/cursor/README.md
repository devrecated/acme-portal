# Cursor kit

Copyright (c) 2026 Devrecated.

This folder is the Autodevelop **Cursor** plugin payload. `.cursor-plugin/plugin.json` points here. `pnpm autodevelop:import` and the kit tar install this tree as the user-scope plugin.

| Path | Workspace (this repo) | Product (customers) |
|---|---|---|
| Rules, hooks, commands, agents, kit skills | `.cursor/` | `kits/cursor/` |

This Autodevelop checkout still uses `.cursor/` so we can develop the host without treating ourselves as a customer. A consumer repo uses this shim plus the starter bind from `kits/autodevelop/` (copied to `.autodevelop/`).

Hook commands in `hooks.json` are rooted at `kits/cursor/hooks/`. Install rewrites those paths to `.cursor/hooks/`. Do not put `services/`, tokens, or a live instance `config.json` here.
