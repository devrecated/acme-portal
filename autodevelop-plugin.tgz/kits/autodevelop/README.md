# Autodevelop workspace kit

Copyright (c) 2026 Devrecated.

Agent-independent bind that every install copies into the consumer repo as `.autodevelop/`. Rules, hooks, and commands stay in `kits/cursor/` (and later `kits/<agent>/`). This folder is config: starter `config.json`, example config, example people, default policies, and hyperparameter examples.

Install copies **missing** files only. A live `.autodevelop/config.json` is never overwritten. The hosted policy pack still writes that organization’s policies after login.

Do not put a live board id, allowlist, or hostname here. This checkout’s tenant bind stays at the repo-root `.autodevelop/` and is not this kit.
