/**
 * Copyright (c) 2026 Devrecated
 *
 * Consumer install pack: one instance's policies, stdio MCP template, and a
 * version manifest. Reuses planPack. Never includes .cursor/private/.
 */
import { createHash } from "node:crypto";
import { existsSync, readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import {
  asInstanceSlug,
  assertPackableFiles,
  dateStamp,
  defaultSlug,
  isForbiddenRel,
  planPack,
  rewriteMcpTemplate,
  yesDefaults,
} from "./pack-client.mjs";

export const VERSION_BASENAME = "VERSION";
export const MANIFEST_BASENAME = "pack-manifest.yaml";

const toPosix = (value) => String(value || "").replaceAll("\\", "/");

export const policiesRel = (slug) => `.cursor/skills/${slug}/autodevelop/.policies`;

export const versionRel = (slug) => `${policiesRel(slug)}/${VERSION_BASENAME}`;

export const manifestRel = (slug) => `${policiesRel(slug)}/${MANIFEST_BASENAME}`;

export const readFileContent = (file) => {
  if (file.kind === "text") return String(file.content ?? "");
  return readFileSync(file.src, "utf8");
};

export const computePackVersion = (files, now = new Date()) => {
  const hash = createHash("sha256");
  const sorted = [...files].sort((a, b) => (a.dest < b.dest ? -1 : a.dest > b.dest ? 1 : 0));
  for (const file of sorted) {
    if (file.dest.endsWith(`/${VERSION_BASENAME}`) || file.dest.endsWith(`/${MANIFEST_BASENAME}`)) {
      continue;
    }
    hash.update(toPosix(file.dest));
    hash.update("\0");
    hash.update(file.content ?? "");
  }
  return `${dateStamp(now).replaceAll("-", ".")}+${hash.digest("hex").slice(0, 12)}`;
};

export const renderPackManifest = ({ slug, version, issuedAt }) =>
  [
    "policyPackVersion: " + JSON.stringify(version),
    "slug: " + JSON.stringify(slug),
    "issuedAt: " + JSON.stringify(issuedAt),
    "",
  ].join("\n");

export const materializePackFiles = (plan) => {
  const files = [];
  for (const file of plan.files || []) {
    const dest = toPosix(file.dest);
    if (dest === "PACK.md") continue;
    files.push({ dest, content: readFileContent(file) });
  }
  return files;
};

export const assertCliPackSafe = (files, slug) => {
  const mapped = (files || []).map((file) => ({
    dest: file.dest,
    src: file.src || file.dest,
    content: file.content,
  }));
  assertPackableFiles(mapped, slug);
  for (const file of mapped) {
    if (isForbiddenRel(file.dest) || String(file.dest).includes(".cursor/private")) {
      throw new Error(`Refusing to pack forbidden path: ${file.dest}`);
    }
  }
};

export const attachPackVersion = ({ files, slug, now = new Date() }) => {
  const issuedAt = now.toISOString();
  const version = computePackVersion(files, now);
  const next = files.filter(
    (file) => file.dest !== versionRel(slug) && file.dest !== manifestRel(slug),
  );
  next.push({ dest: versionRel(slug), content: `${version}\n` });
  next.push({ dest: manifestRel(slug), content: renderPackManifest({ slug, version, issuedAt }) });
  next.sort((a, b) => (a.dest < b.dest ? -1 : a.dest > b.dest ? 1 : 0));
  return { files: next, version, issuedAt };
};

export const starterConfig = (slug) => ({
  slug,
  productName: slug,
  board: { provider: "github" },
  mail: { allowlist: [] },
  singleBranch: true,
  branches: { staging: "master" },
});

/** Pack for a customer slug that is not an instance folder in this kit repo. */
export const buildStarterCliPack = ({ kitRoot, slug, now = new Date() } = {}) => {
  const resolved = asInstanceSlug(slug);
  if (!resolved) throw new Error("Pass a consumer instance slug (not autodevelop or third-party).");
  const policiesDir = join(kitRoot, ".cursor", "skills", "autodevelop", ".policies");
  if (!existsSync(policiesDir)) {
    throw new Error(`Kit policies not found at ${policiesDir}`);
  }
  const destPrefix = `.cursor/skills/${resolved}/autodevelop`;
  const files = [];
  for (const name of readdirSync(policiesDir).sort()) {
    if (!name.endsWith(".example.yaml")) continue;
    const live = name.replace(/\.example\.yaml$/, ".yaml");
    files.push({
      dest: `${destPrefix}/.policies/${live}`,
      content: readFileSync(join(policiesDir, name), "utf8"),
    });
  }
  files.push({
    dest: `${destPrefix}/config.json`,
    content: `${JSON.stringify(starterConfig(resolved), null, 2)}\n`,
  });
  const mcpSrc = join(kitRoot, "mcp.json");
  if (!existsSync(mcpSrc)) throw new Error(`mcp.json not found at ${mcpSrc}`);
  files.push({ dest: "mcp.json", content: rewriteMcpTemplate(readFileSync(mcpSrc, "utf8")) });
  const { files: next, version, issuedAt } = attachPackVersion({ files, slug: resolved, now });
  assertCliPackSafe(next, resolved);
  return { slug: resolved, version, issuedAt, files: next };
};

export const buildCliPack = ({ root, kitRoot, slug, now = new Date() } = {}) => {
  const resolved = asInstanceSlug(slug) || defaultSlug(root);
  if (!resolved) throw new Error("Pass a consumer instance slug (not autodevelop or third-party).");
  const options = {
    ...yesDefaults({ root, now, slug: resolved }),
    includePolicies: true,
    includeMcp: true,
    includeInstanceConfig: false,
    includeExamples: false,
    includeKitShim: false,
    includeFullKit: false,
  };
  const plan = planPack({ root, kitRoot, options });
  const materialized = materializePackFiles(plan);
  const { files, version, issuedAt } = attachPackVersion({ files: materialized, slug: resolved, now });
  assertCliPackSafe(files, resolved);
  return { slug: resolved, version, issuedAt, files };
};

export const readLocalPackVersion = (root, slug) => {
  const resolved = asInstanceSlug(slug);
  if (!resolved || !root) return "";
  const path = join(root, ".cursor", "skills", resolved, "autodevelop", ".policies", VERSION_BASENAME);
  if (!existsSync(path)) return "";
  return readFileSync(path, "utf8").trim();
};
