#!/usr/bin/env node
/**
 * Copyright (c) 2026 Devrecated
 * Bundle one instance for a consumer repo. Dry-run unless --apply.
 */
import {
  copyFileSync,
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import { dirname, join, resolve, sep } from "node:path";
import { createInterface } from "node:readline/promises";
import { stdin as stdinStream, stdout as stdoutStream } from "node:process";
import { fileURLToPath } from "node:url";
import {
  findKitRoot,
  findRepoRoot,
  findWorkspaceBindDir,
  listInstanceNames,
  readWorkspaceSlug,
} from "../../.cursor/skills/autodevelop/scripts/config-load.mjs";
import { argValue, fail, hasFlag, parseArgs } from "../../.cursor/skills/autodevelop/scripts/lib.mjs";

export const KIT_SLUGS = new Set(["autodevelop", "third-party"]);
export const DEFAULT_INSTANCE_SLUG = "devrecated";
export const MCP_PLACEHOLDER = "__PLUGIN_ROOT__";
export const HANDBOOK_CONFIG_URL = "https://devrecated.github.io/autodevelop/configure";

const FORBIDDEN_BASENAMES = new Set([".env", "firebase-admin.json", "serviceAccount.json"]);
const FORBIDDEN_SEGMENTS = new Set(["node_modules", ".git"]);
const SKIP_WALK_NAMES = new Set([".DS_Store", "node_modules", ".git"]);

const toPosix = (value) => String(value || "").replaceAll("\\", "/");

export const asInstanceSlug = (value) => {
  const name = String(value || "")
    .trim()
    .toLowerCase();
  if (!/^[a-z][a-z0-9-]{1,48}$/.test(name) || KIT_SLUGS.has(name)) return "";
  return name;
};

export const dateStamp = (now = new Date()) => {
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

export const defaultSlug = (root) => {
  const names = listInstanceNames(root);
  if (names.includes(DEFAULT_INSTANCE_SLUG)) return DEFAULT_INSTANCE_SLUG;
  return names[0] || "";
};

export const defaultOutputDir = (root, slug, now = new Date()) =>
  join(root, ".cursor", "local", "packs", `${slug || "pack"}-${dateStamp(now)}`);

export const isForbiddenRel = (value) => {
  const n = toPosix(value);
  if (!n) return false;
  if (n.includes(".cursor/private")) return true;
  if (n === "web" || n.startsWith("web/") || n.includes("/web/")) return true;
  if (n === "apps" || n.startsWith("apps/") || n.includes("/apps/")) return true;
  if (n === "services" || n.startsWith("services/") || n.includes("/services/")) return true;
  if (n.includes("docs/.vitepress/dist")) return true;
  const parts = n.split("/").filter(Boolean);
  const base = parts[parts.length - 1] || "";
  if (FORBIDDEN_BASENAMES.has(base)) return true;
  if (base.startsWith(".env")) return true;
  if (parts.some((part) => FORBIDDEN_SEGMENTS.has(part))) return true;
  return false;
};

export const instanceFolderOf = (rel) => {
  const n = toPosix(rel);
  if (n === ".autodevelop" || n.startsWith(".autodevelop/")) return ".autodevelop";
  const match = n.match(/(?:^|\/)\.cursor\/skills\/([^/]+)\//);
  return match ? match[1] : "";
};

export const assertPackableFiles = (files, slug) => {
  for (const file of files) {
    const dest = toPosix(file.dest);
    if (isForbiddenRel(dest) || isForbiddenRel(file.src)) {
      throw new Error(`Refusing to pack forbidden path: ${dest || file.src}`);
    }
    const folder = instanceFolderOf(dest);
    if (folder && folder !== ".autodevelop" && !KIT_SLUGS.has(folder) && folder !== slug) {
      throw new Error(`Refusing to pack a second instance folder: ${folder}`);
    }
  }
};

export const rewriteMcpTemplate = (raw) =>
  String(raw || "").replaceAll("${PLUGIN_ROOT}", MCP_PLACEHOLDER);

export const parseYesNo = (raw, fallback) => {
  const value = String(raw || "")
    .trim()
    .toLowerCase();
  if (!value) return fallback;
  if (["y", "yes"].includes(value)) return true;
  if (["n", "no"].includes(value)) return false;
  return fallback;
};

export const yesDefaults = ({ root, now = new Date(), slug } = {}) => {
  const resolved = asInstanceSlug(slug) || defaultSlug(root);
  return {
    slug: resolved,
    out: defaultOutputDir(root, resolved, now),
    includePolicies: true,
    includeMcp: true,
    includeInstanceConfig: false,
    includeExamples: false,
    includeKitShim: false,
    includeFullKit: false,
    apply: false,
  };
};

export const flagsFromArgs = (args) => {
  const flags = {};
  const slug = argValue(args, "slug");
  if (slug) flags.slug = slug;
  const out = argValue(args, "out");
  if (out) flags.out = out;
  if (hasFlag(args, "no-policies")) flags.includePolicies = false;
  else if (hasFlag(args, "policies")) flags.includePolicies = true;
  if (hasFlag(args, "no-mcp")) flags.includeMcp = false;
  else if (hasFlag(args, "mcp")) flags.includeMcp = true;
  if (hasFlag(args, "no-include-instance-config")) flags.includeInstanceConfig = false;
  else if (hasFlag(args, "include-instance-config")) flags.includeInstanceConfig = true;
  if (hasFlag(args, "no-examples")) flags.includeExamples = false;
  else if (hasFlag(args, "examples")) flags.includeExamples = true;
  if (hasFlag(args, "kit-shim")) flags.includeKitShim = true;
  if (hasFlag(args, "no-kit-shim")) flags.includeKitShim = false;
  if (hasFlag(args, "full-kit")) flags.includeFullKit = true;
  if (hasFlag(args, "no-full-kit")) flags.includeFullKit = false;
  if (hasFlag(args, "dry-run")) flags.apply = false;
  else if (hasFlag(args, "apply")) flags.apply = true;
  if (hasFlag(args, "yes")) flags.yes = true;
  return flags;
};

export const resolveOptions = ({ root, args, now = new Date() } = {}) => {
  const flags = flagsFromArgs(args);
  const defaults = yesDefaults({ root, now, slug: flags.slug });
  const merged = { ...defaults };
  for (const [key, value] of Object.entries(flags)) {
    if (key === "yes" || value === undefined || value === "") continue;
    merged[key] = value;
  }
  return merged;
};

const ASK_ORDER = ["out", "policies", "mcp", "instanceConfig", "examples", "apply"];

const ASK_KEYS = {
  out: "out",
  policies: "includePolicies",
  mcp: "includeMcp",
  instanceConfig: "includeInstanceConfig",
  examples: "includeExamples",
  apply: "apply",
};

export const completeOptions = async ({ defaults, flags = {}, ask } = {}) => {
  const opts = { ...defaults, ...flags };
  delete opts.yes;
  if (ask) {
    if (flags.slug === undefined) {
      opts.slug = asInstanceSlug(await ask("slug", defaults.slug, "text")) || defaults.slug;
    }
    for (const id of ASK_ORDER) {
      const key = ASK_KEYS[id];
      if (flags[key] !== undefined) continue;
      const kind = id === "out" ? "text" : "bool";
      opts[key] = await ask(id, defaults[key], kind);
    }
  }
  opts.slug = asInstanceSlug(opts.slug);
  if (!opts.slug) throw new Error("Pass --slug <instance> (not autodevelop or third-party).");
  return opts;
};

const listYamlNames = (dir, { examples = false } = {}) => {
  if (!dir || !existsSync(dir)) return [];
  return readdirSync(dir)
    .filter((name) => name.endsWith(".yaml"))
    .filter((name) => (examples ? name.endsWith(".example.yaml") : !name.endsWith(".example.yaml")))
    .sort();
};

const addCopy = (files, src, dest) => {
  files.push({ kind: "copy", src, dest: toPosix(dest) });
};

const addText = (files, dest, content) => {
  files.push({ kind: "text", dest: toPosix(dest), content });
};

const walkKitFiles = (dir, baseRel, files) => {
  if (!existsSync(dir)) return;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (SKIP_WALK_NAMES.has(entry.name)) continue;
    const rel = toPosix(join(baseRel, entry.name));
    if (isForbiddenRel(rel)) continue;
    const src = join(dir, entry.name);
    if (entry.isDirectory()) {
      walkKitFiles(src, rel, files);
      continue;
    }
    if (!entry.isFile()) continue;
    addCopy(files, src, rel);
  }
};

export const planPack = ({ root, kitRoot, options } = {}) => {
  const workspace = root || findRepoRoot();
  const kit = kitRoot || findKitRoot();
  const slug = asInstanceSlug(options?.slug);
  if (!slug) throw new Error("Pass --slug <instance> (not autodevelop or third-party).");
  const bindDir = findWorkspaceBindDir(workspace);
  const bindSlug = bindDir ? readWorkspaceSlug(bindDir) : "";
  const useWorkspace = Boolean(bindDir && bindSlug === slug);
  const legacyDir = join(workspace, ".cursor", "skills", slug);
  if (!useWorkspace && !existsSync(legacyDir)) {
    const found = listInstanceNames(workspace).join(", ") || "(none)";
    throw new Error(`Unknown instance slug: ${slug}. Found: ${found}`);
  }
  const instanceAutodevelop = useWorkspace ? bindDir : join(legacyDir, "autodevelop");
  const destPrefix = useWorkspace
    ? ".autodevelop"
    : join(".cursor", "skills", slug, "autodevelop");
  const out = resolve(String(options.out || defaultOutputDir(workspace, slug)));
  if (isForbiddenRel(out) || toPosix(out).includes(".cursor/private")) {
    throw new Error(`Refusing output directory: ${out}`);
  }

  const files = [];
  const policiesDir = join(instanceAutodevelop, ".policies");
  if (options.includePolicies !== false) {
    for (const name of listYamlNames(policiesDir)) {
      addCopy(files, join(policiesDir, name), join(destPrefix, ".policies", name));
    }
  }
  if (options.includeInstanceConfig) {
    for (const name of ["config.json", "people.json"]) {
      const src = join(instanceAutodevelop, name);
      if (!existsSync(src)) continue;
      addCopy(files, src, join(destPrefix, name));
    }
  }
  if (options.includeExamples) {
    const kitPolicies = join(kit, ".cursor", "skills", "autodevelop", ".policies");
    for (const name of listYamlNames(kitPolicies, { examples: true })) {
      addCopy(
        files,
        join(kitPolicies, name),
        join(".cursor", "skills", "autodevelop", ".policies", name),
      );
    }
  }
  if (options.includeMcp !== false) {
    const src = join(kit, "mcp.json");
    if (!existsSync(src)) throw new Error(`mcp.json not found at ${src}`);
    addText(files, "mcp.json", rewriteMcpTemplate(readFileSync(src, "utf8")));
  }
  if (options.includeKitShim) {
    const src = join(kit, ".cursor", "hooks.json");
    if (!existsSync(src)) throw new Error(`hooks.json not found at ${src}`);
    addCopy(files, src, "hooks.json.example");
  }
  if (options.includeFullKit) {
    const kitSkills = join(kit, ".cursor", "skills", "autodevelop");
    if (!existsSync(kitSkills)) throw new Error(`Kit skills not found at ${kitSkills}`);
    walkKitFiles(kitSkills, join(".cursor", "skills", "autodevelop"), files);
  }

  const dests = [...new Set(files.map((file) => file.dest))].sort();
  const unique = dests.map((dest) => files.find((file) => file.dest === dest));
  const readme = renderPackReadme({ slug, options, files: unique });
  addText(unique, "PACK.md", readme);
  unique.sort((a, b) => (a.dest < b.dest ? -1 : a.dest > b.dest ? 1 : 0));
  assertPackableFiles(unique, slug);

  return {
    root: workspace,
    kitRoot: kit,
    slug,
    out,
    options: { ...options, slug, out },
    files: unique,
    dests: unique.map((file) => file.dest),
  };
};

export const renderPackReadme = ({ slug, options, files }) => {
  const dests = new Set((files || []).map((file) => file.dest));
  const hasPolicies = [...dests].some((dest) => dest.includes(".policies/"));
  const hasMcp = dests.has("mcp.json");
  const hasConfig =
    dests.has(toPosix(join(".cursor", "skills", slug, "autodevelop", "config.json"))) ||
    dests.has(".autodevelop/config.json");
  const hasPeople =
    dests.has(toPosix(join(".cursor", "skills", slug, "autodevelop", "people.json"))) ||
    dests.has(".autodevelop/people.json");
  const hasExamples = [...dests].some((dest) => dest.endsWith(".example.yaml"));
  const hasShim = dests.has("hooks.json.example") || options.includeKitShim;
  const hasFull = options.includeFullKit;
  const lines = [
    "# Autodevelop instance pack",
    "",
    `Instance: \`${slug}\``,
    "",
    "This folder is only what that consumer repository should receive. It is not a second plugin. Skills and rules still load from the user-scope Autodevelop plugin.",
    "",
    "## In this pack",
    "",
  ];
  if (hasPolicies) {
    const workspacePolicies = [...dests].some((dest) => dest.startsWith(".autodevelop/.policies/"));
    lines.push(
      workspacePolicies
        ? "- Workspace policies at `.autodevelop/.policies/` (owner/admin UI is the remote source)"
        : `- Instance policies at \`.cursor/skills/${slug}/autodevelop/.policies/\``,
    );
  }
  if (hasMcp) {
    lines.push(
      `- Stdio MCP template (\`mcp.json\`). Replace \`${MCP_PLACEHOLDER}\` with the Autodevelop kit path after import (the plugin symlink).`,
    );
  }
  if (hasConfig || hasPeople) {
    lines.push("- Instance `config.json` and/or `people.json` (board ids and people for this repo)");
  }
  if (hasExamples) {
    lines.push("- Kit policy examples under `.cursor/skills/autodevelop/.policies/` (`*.example.yaml`)");
  }
  if (hasShim) {
    lines.push(
      "- `hooks.json.example` — merge into the consumer `.cursor/hooks.json`. Skills and rules still come from the user-scope plugin, not this folder.",
    );
  }
  if (hasFull) {
    lines.push(
      "- Kit skill bodies under `.cursor/skills/autodevelop/` (unusual). Prefer `pnpm autodevelop:import` unless the workspace cannot load the plugin.",
    );
  }
  if (lines[lines.length - 1] === "") {
    lines.push("- `PACK.md` (this file)");
  }
  lines.push(
    "",
    "## Copy into the consumer repo",
    "",
    "1. Copy `.autodevelop/` (or the legacy `.cursor/skills/<slug>/autodevelop/` folder) into the consumer repository.",
    "2. From an Autodevelop checkout run `pnpm autodevelop:import --apply`, then reload Cursor.",
    `3. Bind people and the GitHub Project: ${HANDBOOK_CONFIG_URL}`,
    "",
    "Do not add `web/`, `services/`, `.cursor/private/`, `.env` files, or Firebase admin JSON. Do not copy another instance folder.",
    "",
  );
  return `${lines.join("\n")}`;
};

export const applyPack = (plan) => {
  mkdirSync(plan.out, { recursive: true });
  const wrote = [];
  for (const file of plan.files) {
    const dest = join(plan.out, file.dest.split("/").join(sep));
    mkdirSync(dirname(dest), { recursive: true });
    if (file.kind === "text") {
      writeFileSync(dest, file.content);
    } else {
      copyFileSync(file.src, dest);
    }
    wrote.push(file.dest);
  }
  return { out: plan.out, wrote };
};

export const printFileList = (plan, { applied } = {}) => {
  const header = applied
    ? `# wrote ${plan.dests.length} files  out=${plan.out}`
    : `# dry-run ${plan.dests.length} files  out=${plan.out}  (pass --apply to write)`;
  process.stdout.write(`${header}\n${plan.dests.join("\n")}\n`);
};

const questionFor = (id, fallback) => {
  if (id === "slug") return `Instance slug [${fallback}]: `;
  if (id === "out") return `Output directory [${fallback}]: `;
  if (id === "policies") return "Include .policies? [Y/n]: ";
  if (id === "mcp") return "Include stdio mcp.json? [Y/n]: ";
  if (id === "instanceConfig") return "Include instance config.json / people.json? [y/N]: ";
  if (id === "examples") return "Include kit example policies? [y/N]: ";
  if (id === "apply") return "Write files now (not a dry-run)? [y/N]: ";
  return `${id} [${fallback}]: `;
};

export const createReadlineAsk = (input = stdinStream, output = stdoutStream) => {
  const rl = createInterface({ input, output });
  return {
    ask: async (id, fallback, kind = "text") => {
      const raw = await rl.question(questionFor(id, fallback));
      if (kind === "bool") return parseYesNo(raw, fallback);
      const trimmed = String(raw || "").trim();
      return trimmed || fallback;
    },
    close: () => rl.close(),
  };
};

const isMain = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMain) {
  const args = parseArgs();
  try {
    const root = findRepoRoot();
    const kitRoot = findKitRoot();
    const flags = flagsFromArgs(args);
    const defaults = yesDefaults({ root, slug: flags.slug });
    const interactive = !flags.yes && stdinStream.isTTY;
    let options;
    if (interactive) {
      const rl = createReadlineAsk();
      try {
        options = await completeOptions({ defaults, flags, ask: rl.ask });
      } finally {
        rl.close();
      }
    } else {
      options = await completeOptions({ defaults, flags });
      if (!options.slug) throw new Error("Pass --slug <instance> or --yes.");
    }
    options.out = resolve(root, String(options.out));
    const plan = planPack({ root, kitRoot, options });
    if (!options.apply) {
      printFileList(plan, { applied: false });
      process.exit(0);
    }
    applyPack(plan);
    printFileList(plan, { applied: true });
  } catch (error) {
    fail(error.message);
  }
}
