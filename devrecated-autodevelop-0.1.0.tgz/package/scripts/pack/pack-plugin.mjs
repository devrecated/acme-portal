#!/usr/bin/env node
/**
 * Copyright (c) 2026 Devrecated
 *
 * Pack the shippable Cursor plugin (not the host) as a tar.gz.
 * Does not include services/, web/, tokens, or instance bindings.
 */
import { spawnSync } from "node:child_process";
import {
  cpSync,
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { findKitRoot } from "../../.cursor/skills/autodevelop-internal/scripts/config-load.mjs";
import { argValue, hasFlag, parseArgs } from "../../.cursor/skills/autodevelop-internal/scripts/lib.mjs";
import { writeWorkspaceMcp } from "../../packages/cli/workspace-mcp.mjs";

export const PLUGIN_TAR_REL = "autodevelop-plugin.tgz";
export const PLUGIN_EXTRACT_REL = ".cursor/local/autodevelop-plugin";
export const CURSOR_KIT_REL = "kits/cursor";
export const AUTODEVELOP_KIT_REL = "kits/autodevelop";
export const WORKSPACE_BIND_REL = ".autodevelop";

export const PLUGIN_TAR_ENTRIES = Object.freeze([
  ".cursor-plugin",
  CURSOR_KIT_REL,
  AUTODEVELOP_KIT_REL,
  "mcp.json",
  "README.md",
]);

const FORBIDDEN_SEGMENTS = new Set(["services", "web", "node_modules", ".git", ".cursor/private"]);

export const pluginTarPath = (repo) => join(resolve(repo), PLUGIN_TAR_REL);

export const pluginExtractPath = (repo) => join(resolve(repo), PLUGIN_EXTRACT_REL);

export const workspaceMcpJson = (raw) =>
  String(raw || "")
    .replaceAll(`/${CURSOR_KIT_REL}/skills/autodevelop-internal/`, "/.cursor/skills/autodevelop-internal/")
    .replaceAll("/.cursor-template/skills/autodevelop-internal/", "/.cursor/skills/autodevelop-internal/");

export const pluginMcpJson = (raw) =>
  String(raw || "")
    .replaceAll("/.cursor-template/skills/autodevelop-internal/", `/${CURSOR_KIT_REL}/skills/autodevelop-internal/`)
    .replaceAll("/.cursor/skills/autodevelop-internal/", `/${CURSOR_KIT_REL}/skills/autodevelop-internal/`);

export const pluginTarReadme = () =>
  [
    "# Autodevelop kit",
    "",
    "Copyright (c) 2026 Devrecated.",
    "",
    "This archive is the kit the customer GitHub Package applies into a consumer repository.",
    "It is not the hosted brain, API, or worker.",
    "",
    "Clients install the private `@devrecated/autodevelop` tarball. `npx autodevelop login`",
    "extracts this tar and writes rules, hooks, commands, agents, and kit skills into `.cursor/`.",
    "The Autodevelop kit copies missing starter files into `.autodevelop/`.",
    "A live `config.json` is never overwritten.",
    "",
    "Do not put tokens or `services/` in this archive.",
    "",
  ].join("\n");

const assertSafeRel = (rel) => {
  const n = String(rel || "").replaceAll("\\", "/");
  if (!n || n.includes("..")) throw new Error(`Refusing plugin path: ${rel}`);
  const parts = n.split("/").filter(Boolean);
  if (parts.some((part) => FORBIDDEN_SEGMENTS.has(part))) {
    throw new Error(`Refusing to pack ${rel}`);
  }
};

const walkRels = (dir, prefix = "") => {
  const out = [];
  if (!existsSync(dir)) return out;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) {
      if (FORBIDDEN_SEGMENTS.has(entry.name)) continue;
      out.push(...walkRels(join(dir, entry.name), rel));
    } else {
      out.push(rel);
    }
  }
  return out;
};

export const copyMissingTree = (src, dest, { skipRootReadme = true } = {}) => {
  if (!src || !existsSync(src)) return [];
  const copied = [];
  const walk = (from, to, atRoot) => {
    mkdirSync(to, { recursive: true });
    for (const entry of readdirSync(from, { withFileTypes: true })) {
      if (atRoot && skipRootReadme && entry.name === "README.md") continue;
      const fromPath = join(from, entry.name);
      const toPath = join(to, entry.name);
      if (entry.isDirectory()) {
        walk(fromPath, toPath, false);
        continue;
      }
      if (existsSync(toPath)) continue;
      mkdirSync(dirname(toPath), { recursive: true });
      cpSync(fromPath, toPath);
      copied.push(toPath);
    }
  };
  walk(src, dest, true);
  return copied;
};

const resolveAutodevelopKit = ({ pluginRoot, kitRoot } = {}) => {
  if (pluginRoot && existsSync(join(pluginRoot, AUTODEVELOP_KIT_REL))) {
    return join(pluginRoot, AUTODEVELOP_KIT_REL);
  }
  const kit = kitRoot || findKitRoot();
  if (existsSync(join(kit, AUTODEVELOP_KIT_REL))) return join(kit, AUTODEVELOP_KIT_REL);
  return "";
};

export const stagePlugin = (kitRoot, stage) => {
  const pluginDir = join(kitRoot, ".cursor-plugin");
  const cursorKitDir = join(kitRoot, CURSOR_KIT_REL);
  const autodevelopKitDir = join(kitRoot, AUTODEVELOP_KIT_REL);
  const mcpSrc = join(kitRoot, "mcp.json");
  if (!existsSync(pluginDir) || !existsSync(join(pluginDir, "plugin.json"))) {
    throw new Error("Missing .cursor-plugin/plugin.json");
  }
  if (!existsSync(cursorKitDir)) {
    throw new Error(`Missing ${CURSOR_KIT_REL}/`);
  }
  if (!existsSync(mcpSrc)) {
    throw new Error("Missing mcp.json");
  }
  if (!existsSync(autodevelopKitDir)) {
    throw new Error(`Missing ${AUTODEVELOP_KIT_REL}/`);
  }
  mkdirSync(stage, { recursive: true });
  cpSync(pluginDir, join(stage, ".cursor-plugin"), { recursive: true });
  cpSync(cursorKitDir, join(stage, CURSOR_KIT_REL), { recursive: true });
  cpSync(autodevelopKitDir, join(stage, AUTODEVELOP_KIT_REL), { recursive: true });
  writeFileSync(join(stage, "mcp.json"), pluginMcpJson(readFileSync(mcpSrc, "utf8")));
  writeFileSync(join(stage, "README.md"), pluginTarReadme());
  for (const rel of walkRels(stage)) {
    assertSafeRel(rel);
    if (rel.includes("services/") || rel.startsWith("web/") || rel.includes(".cursor/private")) {
      throw new Error(`Refusing to pack ${rel}`);
    }
  }
  return stage;
};

export const packPluginTar = ({ kitRoot, destFile } = {}) => {
  const kit = kitRoot || findKitRoot();
  const dest = resolve(destFile || pluginTarPath(kit));
  const stage = mkdtempSync(join(tmpdir(), "ad-plugin-pack-"));
  try {
    stagePlugin(kit, stage);
    mkdirSync(dirname(dest), { recursive: true });
    const result = spawnSync("tar", ["-czf", dest, "-C", stage, "."], { encoding: "utf8" });
    if (result.status !== 0) {
      throw new Error(result.stderr || result.stdout || "tar -czf failed");
    }
  } finally {
    rmSync(stage, { recursive: true, force: true });
  }
  return { tar: dest, entries: [...PLUGIN_TAR_ENTRIES] };
};

export const extractPluginTar = (tarFile, destDir) => {
  const dest = resolve(destDir);
  // Wipe first — a stale stage can resurrect deleted process rules under kits/cursor/rules.
  if (existsSync(dest)) rmSync(dest, { recursive: true, force: true });
  mkdirSync(dest, { recursive: true });
  const result = spawnSync("tar", ["-xzf", resolve(tarFile), "-C", dest], { encoding: "utf8" });
  if (result.status !== 0) {
    throw new Error(result.stderr || result.stdout || "tar -xzf failed");
  }
  return dest;
};

const resolveCursorKit = ({ pluginRoot, kitRoot } = {}) => {
  if (pluginRoot && existsSync(join(pluginRoot, CURSOR_KIT_REL))) {
    return join(pluginRoot, CURSOR_KIT_REL);
  }
  if (pluginRoot && existsSync(join(pluginRoot, ".cursor-template"))) {
    return join(pluginRoot, ".cursor-template");
  }
  const kit = kitRoot || findKitRoot();
  if (existsSync(join(kit, CURSOR_KIT_REL))) return join(kit, CURSOR_KIT_REL);
  if (existsSync(join(kit, ".cursor-template"))) return join(kit, ".cursor-template");
  return "";
};

export const applyPluginToWorkspace = ({ pluginRoot, workspaceRoot, kitRoot } = {}) => {
  const workspace = resolve(workspaceRoot);
  const source = resolveCursorKit({ pluginRoot, kitRoot });
  if (!source || !existsSync(source)) {
    throw new Error(`Missing ${CURSOR_KIT_REL} in the plugin extract`);
  }
  const cursor = join(workspace, ".cursor");
  mkdirSync(cursor, { recursive: true });
  for (const name of ["rules", "hooks", "commands", "agents"]) {
    const src = join(source, name);
    const dest = join(cursor, name);
    // Replace, do not merge — a thin kit must drop previously installed process rules.
    if (existsSync(dest)) rmSync(dest, { recursive: true, force: true });
    if (!existsSync(src)) continue;
    cpSync(src, dest, { recursive: true });
  }
  // Prefer autodevelop-internal (renamed kit); fall back to legacy autodevelop.
  const skillSlug = existsSync(join(source, "skills", "autodevelop-internal"))
    ? "autodevelop-internal"
    : "autodevelop";
  const kitSkills = join(source, "skills", skillSlug);
  if (existsSync(kitSkills)) {
    const skillsDest = join(cursor, "skills", skillSlug);
    if (existsSync(skillsDest)) rmSync(skillsDest, { recursive: true, force: true });
    cpSync(kitSkills, skillsDest, { recursive: true });
  }
  const hooksSrc = join(source, "hooks.json");
  if (existsSync(hooksSrc)) {
    writeFileSync(
      join(cursor, "hooks.json"),
      readFileSync(hooksSrc, "utf8")
        .replaceAll(`${CURSOR_KIT_REL}/hooks/`, ".cursor/hooks/")
        .replaceAll(".cursor-template/hooks/", ".cursor/hooks/"),
    );
  }
  writeWorkspaceMcp(workspace);
  const bindSource = resolveAutodevelopKit({ pluginRoot, kitRoot });
  const bind = join(workspace, WORKSPACE_BIND_REL);
  const bindCopied = bindSource ? copyMissingTree(bindSource, bind) : [];
  return {
    workspace,
    rules: join(cursor, "rules"),
    hooks: join(cursor, "hooks.json"),
    bind,
    bindCopied,
  };
};

export const applyKitFromTar = ({ tarFile, workspaceRoot } = {}) => {
  const tar = resolve(tarFile || "");
  if (!tar || !existsSync(tar)) {
    throw new Error("Missing Autodevelop kit tar (autodevelop-plugin.tgz)");
  }
  const extracted = extractPluginTar(tar, pluginExtractPath(workspaceRoot));
  const applied = applyPluginToWorkspace({ pluginRoot: extracted, workspaceRoot });
  return { tar, extracted, applied };
};

export const deliverPlugin = ({ kitRoot, destRepo, apply = true } = {}) => {
  const kit = kitRoot || findKitRoot();
  const repo = resolve(destRepo || kit);
  const packed = packPluginTar({ kitRoot: kit, destFile: pluginTarPath(repo) });
  const extracted = extractPluginTar(packed.tar, pluginExtractPath(repo));
  const applied = apply ? applyPluginToWorkspace({ pluginRoot: extracted, workspaceRoot: repo, kitRoot: kit }) : null;
  return { tar: packed.tar, extracted, applied, repo };
};

const printDeliver = (result) => {
  const lines = [
    `Plugin tar: ${result.tar}`,
    `Plugin extract: ${result.extracted}`,
    result.applied
      ? `Plugin applied into ${result.repo}/.cursor and missing ${WORKSPACE_BIND_REL}/ files`
      : "Plugin kit was not copied into .cursor/ (pass --apply).",
  ];
  process.stdout.write(`${lines.join("\n")}\n`);
};

const isDirectRun =
  Boolean(process.argv[1]) && import.meta.url === pathToFileURL(process.argv[1]).href;
if (isDirectRun) {
  const args = parseArgs(process.argv.slice(2));
  const kitRoot = findKitRoot();
  const repo = argValue(args, "repo") || kitRoot;
  const destFile = argValue(args, "out") || pluginTarPath(repo);
  if (argValue(args, "repo") || hasFlag(args, "apply")) {
    printDeliver(
      deliverPlugin({
        kitRoot,
        destRepo: repo,
        apply: hasFlag(args, "apply") || Boolean(argValue(args, "repo")),
      }),
    );
  } else {
    const packed = packPluginTar({ kitRoot, destFile });
    process.stdout.write(`Plugin tar: ${packed.tar}\n`);
  }
}
