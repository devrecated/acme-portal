# @devrecated/autodevelop

Copyright (c) 2026 Devrecated.

Private customer CLI. Not listed on the public npm registry. The package includes
`autodevelop-plugin.tgz`. `login` / `install` extract that tar into the current
repository, then write the organization policy pack from the Autodevelop host.

Install the operator-issued tarball (from `pnpm pack:npm`), then:

```bash
npx autodevelop login
npx autodevelop github init
# then Developer: Reload Window
```

Do not copy this archive into `~/.cursor/plugins/local`. Cursor loads skills from the repo after install.
