# @devrecated/autodevelop

Copyright (c) 2026 Devrecated.

Private customer CLI. Not listed on the public npm registry. The package includes
`autodevelop-plugin.tgz`. `login` / `install` extract that tar into the current
repository, write Cursor project MCP and the user Cursor config, then write the
organization policy pack from the Autodevelop host. Reload the window.

Install the operator-issued tarball (from `pnpm pack:npm`). Prefer pnpm in a
pnpm workspace. `npm i ./file.tgz` used to crash arborist (`matches` of null)
because packed `file:` deps were resolved against the consumer, not the tarball.

```bash
pnpm add ./devrecated-autodevelop-0.1.0.tgz
# or, after this pack (bundled workspace packages, no file: specs):
npm install ./devrecated-autodevelop-0.1.0.tgz
npx autodevelop login
npx autodevelop github init
# then Developer: Reload Window
```

Do not copy this archive into `~/.cursor/plugins/local`. Cursor loads skills from the repo after install.
