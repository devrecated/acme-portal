/**
 * Copyright (c) 2026 Devrecated
 *
 * Resolve the kit tar shipped in the GitHub Package (or packed from this checkout).
 */
import { existsSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { findKitRoot } from "../../.cursor/skills/autodevelop/scripts/config-load.mjs";
import { applyKitFromTar, packPluginTar, PLUGIN_TAR_REL } from "../../scripts/pack-plugin.mjs";

export const KIT_TAR_MISSING =
  "This install is missing autodevelop-plugin.tgz. Use the private Autodevelop package tarball.";

export const cliPackageDir = (fromUrl = import.meta.url) => dirname(fileURLToPath(fromUrl));

const tryKitRoot = (kitRoot) => {
  if (kitRoot) return resolve(kitRoot);
  try {
    return findKitRoot();
  } catch {
    return "";
  }
};

export const resolvePluginTar = ({ env = process.env, packageDir, kitRoot } = {}) => {
  const override = String(env.AUTODEVELOP_PLUGIN_TAR || "").trim();
  if (override) {
    const abs = resolve(override);
    if (!existsSync(abs)) {
      throw new Error(`AUTODEVELOP_PLUGIN_TAR is missing: ${override}`);
    }
    return abs;
  }
  const pkg = resolve(packageDir || cliPackageDir());
  const bundled = join(pkg, PLUGIN_TAR_REL);
  if (existsSync(bundled)) return bundled;
  const kit = tryKitRoot(kitRoot);
  if (kit && existsSync(join(kit, ".cursor-template"))) {
    return packPluginTar({ kitRoot: kit, destFile: bundled }).tar;
  }
  throw new Error(KIT_TAR_MISSING);
};

export const applyBundledKit = ({ cwd, env = process.env, packageDir, kitRoot, pluginTar } = {}) => {
  const tarFile = pluginTar || resolvePluginTar({ env, packageDir, kitRoot });
  return applyKitFromTar({ tarFile, workspaceRoot: cwd });
};
