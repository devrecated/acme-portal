#!/usr/bin/env node
/**
 * Copyright (c) 2026 Devrecated
 *
 * Cursor user-global launcher. Walks from cwd for the kit MCP in this repo.
 * Copied next to credentials on login. No tokens.
 */
import { existsSync, realpathSync } from "node:fs";
import { spawn } from "node:child_process";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

export const KIT_SERVER_REL = join(".cursor", "skills", "autodevelop", "mcp", "server.mjs");

export const findKitServer = (start = process.cwd()) => {
  let dir = start;
  for (;;) {
    const candidate = join(dir, KIT_SERVER_REL);
    if (existsSync(candidate)) return candidate;
    const parent = dirname(dir);
    if (parent === dir) return "";
    dir = parent;
  }
};

export const missingKitMessage =
  "Autodevelop is not installed in this repository. Run npx @devrecated/autodevelop login from the project root.";

const runKitMcp = (start = process.cwd()) => {
  const found = findKitServer(start);
  if (!found) {
    process.stderr.write(`${missingKitMessage}\n`);
    process.exit(1);
  }
  const child = spawn(process.execPath, [found], { stdio: "inherit" });
  child.on("error", (error) => {
    process.stderr.write(`${error.message}\n`);
    process.exit(1);
  });
  child.on("exit", (code, signal) => {
    if (signal) process.exit(1);
    process.exit(code ?? 0);
  });
};

const isMain = (() => {
  if (!process.argv[1]) return false;
  try {
    return realpathSync(fileURLToPath(import.meta.url)) === realpathSync(process.argv[1]);
  } catch {
    return fileURLToPath(import.meta.url) === process.argv[1];
  }
})();

if (isMain) runKitMcp();
