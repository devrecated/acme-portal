/**
 * Copyright (c) 2026 Devrecated
 */
import { argValue, hasFlag, parseArgs } from "../../.cursor/skills/autodevelop/scripts/lib.mjs";

export const COMMANDS = ["login", "logout", "status", "install", "github", "mcp", "users", "orgs", "seed", "sandbox"];
export const USER_COMMANDS = ["list", "add", "grants", "link-operator"];
export const ORG_COMMANDS = ["create"];
export const GITHUB_COMMANDS = ["init", "status", "token"];

const commandList = "login, logout, status, install, github, mcp, users, orgs, seed, or sandbox";

export const parseCli = (argv = process.argv.slice(2)) => {
  const args = parseArgs(argv);
  const command = String(args.positional[0] || "").trim();
  if (command && !COMMANDS.includes(command)) {
    const err = new Error(`Unknown command: ${command}. Use ${commandList}.`);
    err.code = "usage";
    throw err;
  }
  const userCommand = command === "users" ? String(args.positional[1] || "").trim() : "";
  if (userCommand && !USER_COMMANDS.includes(userCommand)) {
    const err = new Error(`Unknown users command: ${userCommand}. Use list, add, grants, or link-operator.`);
    err.code = "usage";
    throw err;
  }
  const orgCommand = command === "orgs" ? String(args.positional[1] || "").trim() : "";
  if (orgCommand && !ORG_COMMANDS.includes(orgCommand)) {
    const err = new Error(`Unknown orgs command: ${orgCommand}. Use create.`);
    err.code = "usage";
    throw err;
  }
  const githubCommand = command === "github" ? String(args.positional[1] || "").trim() : "";
  if (command === "github" && (!githubCommand || !GITHUB_COMMANDS.includes(githubCommand))) {
    const err = new Error("Unknown github command. Use init, status, or token.");
    err.code = "usage";
    throw err;
  }
  return {
    command: command || "status",
    userCommand,
    orgCommand,
    githubCommand,
    host: argValue(args, "host", ""),
    slug: argValue(args, "slug", ""),
    credentials: argValue(args, "credentials", ""),
    org: argValue(args, "org", ""),
    email: argValue(args, "email", ""),
    role: argValue(args, "role", ""),
    name: argValue(args, "name", ""),
    set: argValue(args, "set", ""),
    noInstall: hasFlag(args, "no-install"),
    noOpen: hasFlag(args, "no-open"),
    reset: hasFlag(args, "reset"),
    json: hasFlag(args, "json"),
    help: hasFlag(args, "help") || command === "help",
    args,
  };
};

export const usersUsage = () =>
  [
    "Autodevelop employee users CLI (local ops and tests; not a customer V1 release)",
    "",
    "  pnpm autodevelop users list --org <id> [--json]",
    "  pnpm autodevelop users add --org <id> --email <addr> --role member|owner [--name <label>]",
    "  pnpm autodevelop users grants --org <id> --email <addr> --set <comma grants>",
    "  pnpm autodevelop users link-operator --org <id> --email <addr>",
    "",
    "Every users command requires --org <id>. The CLI never infers an organization.",
    "Invites organization members (ticket UI). link-operator creates the Auth user via the",
    "host service role when the email is not yet in Authentication; otherwise create that",
    "user in Authentication → Users first. Customer V1 user admin is the operator console.",
    "Auth: AUTODEVELOP_ADMIN_KEY (first-boot, X-Admin-Key) from the environment or from",
    "services/.env or services/brain/.env, or a stored login credential with org.manage",
    "(AUTODEVELOP_TOKEN or ~/.config/autodevelop/credentials.json).",
    "Host: AUTODEVELOP_HOST (default http://127.0.0.1:8787). Start the host with pnpm dev.",
    "",
  ].join("\n");

export const orgsUsage = () =>
  [
    "Autodevelop employee orgs CLI (local ops and tests; not a customer V1 release)",
    "",
    "  pnpm autodevelop orgs create --name <organization name> [--json]",
    "",
    "Prints the organization id. Later users commands require --org <that-id>.",
    "Auth and host: same as the users CLI (AUTODEVELOP_ADMIN_KEY or org.manage).",
    "Start the host with pnpm dev.",
    "",
  ].join("\n");

export const seedUsage = () =>
  [
    "Autodevelop employee seed CLI (local ops and tests; not a customer V1 release)",
    "",
    "  pnpm autodevelop seed --name <organization name> [--json]",
    "",
    "Creates the organization and three people:",
    "  client@devrecated.com                 member (ticket UI)",
    "  orgowner@devrecated.com               owner (ticket UI and business console)",
    "  autodevelopemployee@devrecated.com    operator (operator console)",
    "",
    "Prints the organization id once. Later commands require --org <that-id>.",
    "Auth and host: same as the users CLI (AUTODEVELOP_ADMIN_KEY or org.manage).",
    "Start the host with pnpm dev.",
    "",
  ].join("\n");

export const sandboxUsage = () =>
  [
    "Autodevelop employee local sandbox (not a customer V1 release)",
    "",
    "  pnpm sandbox",
    "  pnpm autodevelop sandbox [--name <organization name>] [--reset] [--json]",
    "",
    "Starts a local Supabase in Docker (same Auth and Postgres as hosted, not a remote project),",
    "writes services/.env.sandbox, starts the host and UIs against that stack, and seeds the",
    "three test inboxes when they are missing. --reset wipes the local database and reseeds.",
    "Sign-in: shared local fixture on SANDBOX_PASSWORD (same value for all three inboxes). Not for remote.",
    "This command never reads or writes a remote Supabase URL.",
    "",
  ].join("\n");

export const githubUsage = () =>
  [
    "Autodevelop CLI — GitHub App",
    "",
    "  pnpm autodevelop github init [--host <url>] [--no-open]",
    "  pnpm autodevelop github status [--host <url>]",
    "  pnpm autodevelop github token [--host <url>]",
    "",
    "init opens the Autodevelop GitHub App install page for this organization.",
    "status reports whether the host has recorded that install.",
    "token mints a one-hour installation token. Prints expires_at and the",
    "installation account. Does not print the token.",
    "A lapsed org stops with Your billing has expired.",
    "",
  ].join("\n");

export const usageFor = (command) => {
  if (command === "users") return usersUsage();
  if (command === "orgs") return orgsUsage();
  if (command === "seed") return seedUsage();
  if (command === "sandbox") return sandboxUsage();
  if (command === "github") return githubUsage();
  return usage();
};

export const usage = () =>
  [
    "Autodevelop CLI",
    "",
    "Customer (private package; kit tar then policy pack):",
    "  npx @devrecated/autodevelop login [--host <url>] [--slug <instance>] [--no-install] [--no-open]",
    "  # then Developer: Reload Window",
    "  npx @devrecated/autodevelop logout",
    "  npx @devrecated/autodevelop status",
    "  npx @devrecated/autodevelop install [--slug <instance>]",
    "  npx @devrecated/autodevelop github init",
    "  npx @devrecated/autodevelop github status",
    "  npx @devrecated/autodevelop github token",
    "",
    "In this checkout the same commands are pnpm autodevelop …",
    "",
    "Employee (local ops and tests; not a customer V1 release):",
    "  pnpm sandbox",
    "  pnpm autodevelop sandbox [--name <organization name>] [--reset]",
    "  pnpm autodevelop seed --name <organization name>",
    "  pnpm autodevelop orgs create --name <organization name>",
    "  pnpm autodevelop users list --org <id>",
    "  pnpm autodevelop users add --org <id> --email <addr> --role member|owner [--name <label>]",
    "  pnpm autodevelop users grants --org <id> --email <addr> --set <comma grants>",
    "  pnpm autodevelop users link-operator --org <id> --email <addr>",
    "",
    "users and related commands require --org <id>. They never infer an organization.",
    "Set AUTODEVELOP_HOST for the host origin (default http://127.0.0.1:8787).",
    "AUTODEVELOP_TOKEN wins over the credentials file when set.",
    "Users first-boot: AUTODEVELOP_ADMIN_KEY, or the same key in services/.env or services/brain/.env.",
    "",
  ].join("\n");
