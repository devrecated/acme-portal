/**
 * Copyright (c) 2026 Devrecated
 *
 * Write Cursor user-global MCP after login. No token in the file. Launchers
 * live next to credentials and walk the current workspace.
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { credentialsConfigDir, DIR_MODE } from "./credentials.mjs";
import {
  HOST_MCP_NAME,
  KIT_MCP_NAME,
  LEGACY_HOST_MCP_NAME,
  mergeWorkspaceMcp,
} from "./workspace-mcp.mjs";

export const KIT_LAUNCHER = "kit-mcp.mjs";
export const HOST_LAUNCHER = "host-mcp.mjs";
export const INSTALL_SIDECAR = "install.json";

const here = () => dirname(fileURLToPath(import.meta.url));

export const defaultUserMcpPath = (env = process.env, home = homedir()) => {
  const override = String(env.AUTODEVELOP_USER_MCP || "").trim();
  if (override) return override;
  return join(home, ".cursor", "mcp.json");
};

export const interpolateUserPath = (abs, home = homedir()) => {
  const root = String(home || "").replace(/[/\\]+$/, "");
  const value = String(abs || "");
  if (!root || !value) return value;
  const prefix = `${root}/`;
  const winPrefix = `${root}\\`;
  if (value === root) return "${userHome}";
  if (value.startsWith(prefix) || value.startsWith(winPrefix)) {
    return `\${userHome}${value.slice(root.length).replaceAll("\\", "/")}`;
  }
  return value;
};

export const userMcpServers = (launcherDir, { home = homedir() } = {}) => ({
  [KIT_MCP_NAME]: {
    command: "node",
    args: [interpolateUserPath(join(launcherDir, KIT_LAUNCHER), home)],
  },
  [HOST_MCP_NAME]: {
    command: "node",
    args: [interpolateUserPath(join(launcherDir, HOST_LAUNCHER), home)],
  },
});

export const writeUserLaunchers = (configDir) => {
  mkdirSync(configDir, { recursive: true, mode: DIR_MODE });
  const src = here();
  const wrote = [];
  for (const name of [KIT_LAUNCHER, HOST_LAUNCHER]) {
    const dest = join(configDir, name);
    writeFileSync(dest, readFileSync(join(src, name)));
    wrote.push(dest);
  }
  return wrote;
};

export const recordCliInstallPath = (configDir, cliPath) => {
  const cli = String(cliPath || "").trim();
  if (!cli) return "";
  mkdirSync(configDir, { recursive: true, mode: DIR_MODE });
  const dest = join(configDir, INSTALL_SIDECAR);
  writeFileSync(dest, `${JSON.stringify({ cli }, null, 2)}\n`);
  return dest;
};

export const resolveCliBin = (root, fromUrl = import.meta.url) => {
  if (root) {
    const fromRepo = join(root, "node_modules", "@devrecated", "autodevelop", "packages", "cli", "bin.mjs");
    if (existsSync(fromRepo)) return fromRepo;
  }
  try {
    const self = fileURLToPath(new URL("./bin.mjs", fromUrl));
    if (existsSync(self)) return self;
  } catch {
    /* ignore */
  }
  return "";
};

const readMcpFile = (dest) => {
  if (!existsSync(dest)) return {};
  try {
    const data = JSON.parse(readFileSync(dest, "utf8") || "{}");
    return data && typeof data === "object" ? data : {};
  } catch {
    return {};
  }
};

export const writeUserMcp = ({
  env = process.env,
  home = homedir(),
  userMcpPath,
  credentialsPath,
  cliBin,
  cwd,
} = {}) => {
  const dest = userMcpPath || defaultUserMcpPath(env, home);
  const configDir = credentialsConfigDir(credentialsPath, env, home);
  writeUserLaunchers(configDir);
  recordCliInstallPath(configDir, cliBin || resolveCliBin(cwd));
  const servers = userMcpServers(configDir, { home });
  const next = mergeWorkspaceMcp(readMcpFile(dest), servers);
  mkdirSync(dirname(dest), { recursive: true });
  writeFileSync(dest, `${JSON.stringify(next, null, 2)}\n`);
  return { dest, configDir, servers };
};

export const removeUserAutodevelopMcp = ({ env = process.env, home = homedir(), userMcpPath } = {}) => {
  const dest = userMcpPath || defaultUserMcpPath(env, home);
  if (!existsSync(dest)) return null;
  const current = readMcpFile(dest);
  const prev =
    current.mcpServers && typeof current.mcpServers === "object" ? { ...current.mcpServers } : {};
  delete prev[KIT_MCP_NAME];
  delete prev[HOST_MCP_NAME];
  delete prev[LEGACY_HOST_MCP_NAME];
  mkdirSync(dirname(dest), { recursive: true });
  writeFileSync(dest, `${JSON.stringify({ ...current, mcpServers: prev }, null, 2)}\n`);
  return dest;
};
