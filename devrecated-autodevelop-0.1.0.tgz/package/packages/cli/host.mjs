/**
 * Copyright (c) 2026 Devrecated
 */
export const DEFAULT_HOST = "http://127.0.0.1:8787";

const UNREACHABLE_CODES = new Set([
  "ECONNREFUSED",
  "ENOTFOUND",
  "ECONNRESET",
  "EHOSTUNREACH",
  "ETIMEDOUT",
  "ENETUNREACH",
]);

export const hostOrigin = (env = process.env, override = "", storedHost = "") => {
  const fromFlag = String(override || "").trim();
  if (fromFlag) return fromFlag.replace(/\/$/, "");
  const named = String(env.AUTODEVELOP_HOST || "").trim();
  if (named) return named.replace(/\/$/, "");
  const entitlement = String(env.AUTODEVELOP_ENTITLEMENT_URL || "").trim();
  if (entitlement) return entitlement.replace(/\/entitlement\/?$/i, "").replace(/\/$/, "");
  const stored = String(storedHost || "").trim();
  if (stored) return stored.replace(/\/$/, "");
  return DEFAULT_HOST;
};

export const joinHost = (origin, path) => `${String(origin).replace(/\/$/, "")}${path}`;

export const hostUnreachableMessage = (origin) =>
  `Host is not reachable at ${origin || DEFAULT_HOST}. Start it with pnpm dev.`;

export const isHostUnreachable = (error) => {
  if (!error) return false;
  const message = String(error.message || "");
  if (/^fetch failed$/i.test(message) || /failed to fetch/i.test(message)) return true;
  const code = error.code || error.cause?.code;
  if (code && UNREACHABLE_CODES.has(String(code))) return true;
  if (error.cause && error.cause !== error) return isHostUnreachable(error.cause);
  return false;
};

export const wrapHostFetchError = (error, origin) => {
  if (!isHostUnreachable(error)) return error;
  const next = new Error(hostUnreachableMessage(origin));
  next.cause = error;
  return next;
};
