/**
 * Copyright (c) 2026 Devrecated
 *
 * Machine credentials for the Autodevelop CLI. Never print the token value.
 */
import { chmodSync, existsSync, mkdirSync, readFileSync, unlinkSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { dirname, join } from "node:path";

export const CREDENTIALS_MODE = 0o600;
export const DIR_MODE = 0o700;

export const defaultCredentialsPath = (env = process.env, home = homedir()) => {
  const override = String(env.AUTODEVELOP_CREDENTIALS || "").trim();
  if (override) return override;
  const xdg = String(env.XDG_CONFIG_HOME || "").trim();
  const base = xdg || join(home, ".config");
  return join(base, "autodevelop", "credentials.json");
};

export const readCredentialsFile = (path) => {
  if (!path || !existsSync(path)) return null;
  try {
    const data = JSON.parse(readFileSync(path, "utf8"));
    if (!data || typeof data !== "object") return null;
    const token = String(data.token || "").trim();
    if (!token) return null;
    return {
      token,
      org_id: data.org_id || data.orgId || null,
      issued_at: data.issued_at || data.issuedAt || null,
      host: data.host || null,
    };
  } catch {
    return null;
  }
};

export const writeCredentialsFile = (path, { token, orgId = null, issuedAt = null, host = null } = {}) => {
  const raw = String(token || "").trim();
  if (!raw) throw new Error("Refusing to write empty credentials.");
  mkdirSync(dirname(path), { recursive: true, mode: DIR_MODE });
  writeFileSync(
    path,
    `${JSON.stringify(
      {
        token: raw,
        org_id: orgId || null,
        issued_at: issuedAt || new Date().toISOString(),
        host: host || null,
      },
      null,
      2,
    )}\n`,
    { mode: CREDENTIALS_MODE },
  );
  chmodSync(path, CREDENTIALS_MODE);
  return path;
};

export const clearCredentialsFile = (path) => {
  if (path && existsSync(path)) unlinkSync(path);
};

export const readSubscriptionToken = (env = process.env, { credentialsPath, home } = {}) => {
  const fromEnv = String(env.AUTODEVELOP_TOKEN || "").trim();
  if (fromEnv) return fromEnv;
  const file = readCredentialsFile(credentialsPath || defaultCredentialsPath(env, home));
  if (file?.token) return file.token;
  const plugin = String(env.TOKEN || "").trim();
  return plugin || null;
};

export const tokenSource = (env = process.env, { credentialsPath, home } = {}) => {
  if (String(env.AUTODEVELOP_TOKEN || "").trim()) return "AUTODEVELOP_TOKEN";
  if (readCredentialsFile(credentialsPath || defaultCredentialsPath(env, home))) return "credentials";
  if (String(env.TOKEN || "").trim()) return "TOKEN";
  return null;
};
