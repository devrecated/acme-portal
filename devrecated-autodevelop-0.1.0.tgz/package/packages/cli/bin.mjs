#!/usr/bin/env node
/**
 * Copyright (c) 2026 Devrecated
 *
 * Published GitHub Package entry. Customer commands only. Applies the bundled kit tar.
 */
import { fileURLToPath } from "node:url";
import { fail } from "../../.cursor/skills/autodevelop/scripts/lib.mjs";
import { customerMain } from "./customer.mjs";

const isMain = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMain) {
  customerMain().then(
    (code) => {
      if (code) process.exit(code);
    },
    (error) => fail(error.message),
  );
}
