/**
 * Copyright (c) 2026 Devrecated
 *
 * Customer commands in the private @devrecated/autodevelop package.
 */
import { findRepoRoot, listInstanceNames } from "../../.cursor/skills/autodevelop/scripts/config-load.mjs";
import { readLocalPackVersion } from "../../scripts/pack-client/cli-pack.mjs";
import {
  clearCredentialsFile,
  defaultCredentialsPath,
  readCredentialsFile,
  tokenSource,
} from "./credentials.mjs";
import { runGithubInit, runGithubStatus, runGithubToken } from "./github.mjs";
import { hostOrigin } from "./host.mjs";
import { inferSlug, fetchPackStatus, runInstall } from "./install.mjs";
import { runLogin } from "./login.mjs";
import { runMcpStdio } from "./mcp-host.mjs";
import { parseCli } from "./parse.mjs";

export const CUSTOMER_COMMANDS = new Set(["login", "logout", "status", "install", "github", "mcp"]);

const writeLine = (text) => {
  process.stdout.write(`${text}\n`);
};

export const customerUsage = () =>
  [
    "Autodevelop CLI",
    "",
    "Private @devrecated/autodevelop package. login applies the bundled kit tar",
    "into this repository, then the organization policy pack. Login also writes",
    "Cursor project MCP (`.cursor/mcp.json`). Reload the window. Do not add a local plugin.",
    "",
    "  npx @devrecated/autodevelop login [--host <url>] [--slug <instance>] [--no-install] [--no-open]",
    "  npx @devrecated/autodevelop logout",
    "  npx @devrecated/autodevelop status",
    "  npx @devrecated/autodevelop install [--slug <instance>]",
    "  npx @devrecated/autodevelop github init",
    "  npx @devrecated/autodevelop github status",
    "  npx @devrecated/autodevelop github token",
    "",
    "Set AUTODEVELOP_HOST for the host origin (default http://127.0.0.1:8787).",
    "AUTODEVELOP_TOKEN wins over the credentials file when set.",
    "",
  ].join("\n");

export const runStatus = ({ env = process.env, host, slug: requested, cwd = process.cwd(), credentialsPath } = {}) => {
  const path = credentialsPath || defaultCredentialsPath(env);
  const stored = readCredentialsFile(path);
  const source = tokenSource(env, { credentialsPath: path });
  let root = "";
  try {
    root = findRepoRoot(cwd);
  } catch {
    root = cwd;
  }
  const slug = inferSlug({ root, requested }) || listInstanceNames(root)[0] || "";
  const localVersion = slug ? readLocalPackVersion(root, slug) : "";
  return {
    signedIn: Boolean(source),
    source,
    credentialsPath: path,
    envTokenSet: Boolean(String(env.AUTODEVELOP_TOKEN || "").trim()),
    host: hostOrigin(env, host) || stored?.host || null,
    orgId: stored?.org_id || null,
    issuedAt: stored?.issued_at || null,
    slug: slug || null,
    localVersion: localVersion || null,
  };
};

export const runCustomerCommand = async (opts, env = process.env) => {
  if (!CUSTOMER_COMMANDS.has(opts.command)) return null;
  const credentialsPath = opts.credentials || defaultCredentialsPath(env);
  if (opts.command === "logout") {
    clearCredentialsFile(credentialsPath);
    writeLine("Signed out on this machine. Environment variables are unchanged.");
    return 0;
  }
  if (opts.command === "status") {
    const status = runStatus({
      env,
      host: opts.host,
      slug: opts.slug,
      credentialsPath,
    });
    if (opts.json) {
      writeLine(JSON.stringify(status));
      return 0;
    }
    writeLine(status.signedIn ? "Signed in." : "Not signed in.");
    writeLine(`Source: ${status.source || "none"}`);
    writeLine(`Host: ${status.host || "(unset)"}`);
    if (status.orgId) writeLine(`Organization: ${status.orgId}`);
    if (status.issuedAt) writeLine(`Issued: ${status.issuedAt}`);
    if (status.slug) writeLine(`Instance: ${status.slug}`);
    if (status.localVersion) writeLine(`Local policy pack: ${status.localVersion}`);
    writeLine(`Credentials file: ${status.credentialsPath}`);
    if (status.signedIn && status.localVersion) {
      try {
        const remote = await fetchPackStatus({
          origin: status.host,
          credential: env.AUTODEVELOP_TOKEN || readCredentialsFile(credentialsPath)?.token,
          slug: status.slug,
          localVersion: status.localVersion,
        });
        writeLine(`Hosted policy pack: ${remote.hostedVersion}`);
        if (remote.compatible === false) {
          writeLine("Hosted pack version differs. Ask before running install again.");
        }
      } catch {
        writeLine("Hosted pack version: unreachable");
      }
    }
    return 0;
  }
  if (opts.command === "login") {
    await runLogin({
      env,
      host: opts.host,
      credentialsPath,
      noOpen: opts.noOpen,
    });
    if (!opts.noInstall) {
      await runInstall({ env, host: opts.host, slug: opts.slug, credentialsPath });
    }
    return 0;
  }
  if (opts.command === "install") {
    await runInstall({ env, host: opts.host, slug: opts.slug, credentialsPath });
    return 0;
  }
  if (opts.command === "mcp") {
    await runMcpStdio({ env, host: opts.host, credentialsPath });
    return 0;
  }
  if (opts.command === "github" && opts.githubCommand === "init") {
    const started = await runGithubInit({
      env,
      host: opts.host,
      credentialsPath,
      noOpen: opts.noOpen,
      write: opts.json ? () => {} : process.stdout.write.bind(process.stdout),
    });
    if (opts.json) {
      writeLine(
        JSON.stringify({
          connected: Boolean(started.connected),
          account: started.account || "",
          url: started.url || "",
        }),
      );
    }
    return 0;
  }
  if (opts.command === "github" && opts.githubCommand === "status") {
    const status = await runGithubStatus({
      env,
      host: opts.host,
      credentialsPath,
      write: opts.json ? () => {} : process.stdout.write.bind(process.stdout),
    });
    if (opts.json) {
      writeLine(
        JSON.stringify({
          connected: Boolean(status.connected),
          account: status.account || "",
        }),
      );
    }
    return 0;
  }
  if (opts.command === "github" && opts.githubCommand === "token") {
    const minted = await runGithubToken({
      env,
      host: opts.host,
      credentialsPath,
      write: opts.json ? () => {} : process.stdout.write.bind(process.stdout),
    });
    if (opts.json) {
      writeLine(JSON.stringify({ expires_at: minted.expiresAt, account: minted.account }));
    }
    return 0;
  }
  return null;
};

export const customerMain = async (argv = process.argv.slice(2), env = process.env) => {
  const opts = parseCli(argv);
  if (opts.help) {
    writeLine(customerUsage().trimEnd());
    return 0;
  }
  if (!CUSTOMER_COMMANDS.has(opts.command)) {
    writeLine("This command is not in the customer package. Use the Autodevelop checkout.");
    return 1;
  }
  const code = await runCustomerCommand(opts, env);
  if (code === null) {
    writeLine(customerUsage().trimEnd());
    return 0;
  }
  return code;
};
